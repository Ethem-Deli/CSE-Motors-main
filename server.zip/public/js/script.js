// after the assignments done the needed script will be separated
// from files and will add strech challenge optional if still there is time :) 