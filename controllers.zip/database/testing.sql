SELECT * 
FROM public.classification 
ORDER BY classification_name ASC